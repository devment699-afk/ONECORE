#define COLOR_BLACK FLinearColor(0, 0, 0, 1.f)
#define 深紫 FLinearColor(0.15f, 0.20f, 0.89f, 1.0f )
#define COLOR_AVIWA FLinearColor(0.0f, 0.0f, 0.0f, 0.0f)
#define COLOR_WHITE FLinearColor(1.f, 1.f, 1.f, 1.f)
#define COLOR_RED FLinearColor(1.f, 0, 0, 1.f)
#define COLOR_CAR FLinearColor(1.f, 0.5f, 1.f, 1.f)
#define COLOR_GREEN FLinearColor(0.0f, 1.0f, 0.0f, 1.0f)
#define COLOR_ORANGE FLinearColor(1.f, 0.4f, 0, 1.f)
#define COLOR_YELLOW FLinearColor(1.f, 1.f, 0, 1.f)
#define COLOR_LIME FLinearColor(0, 1.f, 0, 1.f)
#define COLOR_BLUE FLinearColor(0, 0, 1.f, 1.f)
#define COLOR_THISTLE FLinearColor(1.0f, 0.74f, 0.84f, 1.0f)
#define COLOR_PINK FLinearColor(1.0f, 0.75f, 0.8f, 1.0f)
#define TSL_FONT_DEFAULT_SIZE 12

static UFont *tslFont = 0, *robotoTinyFont = 0;




typedef unsigned char BYTE;
typedef uint32_t UINT32;

FVector operator*(const FVector &vector, float scalar)
{
    return {vector.X * scalar, vector.Y * scalar, vector.Z * scalar};
}

FVector operator+(const FVector &lhs, const FVector &rhs)
{
    return {lhs.X + rhs.X, lhs.Y + rhs.Y, lhs.Z + rhs.Z};
}

FVector operator-(const FVector &lhs, const FVector &rhs)
{
    return {lhs.X - rhs.X, lhs.Y - rhs.Y, lhs.Z - rhs.Z};
}

FVector operator*(const FVector &lhs, const FVector &rhs)
{
    return {lhs.X * rhs.X, lhs.Y * rhs.Y, lhs.Z * rhs.Z};
}

FVector operator/(const FVector &lhs, const FVector &rhs)
{
    return {lhs.X / rhs.X, lhs.Y / rhs.Y, lhs.Z / rhs.Z};
}

void DrawTrueTransparentRect(UCanvas* Canvas, FVector2D Position, float Width, float Height, FLinearColor Color)
{
    // K2_DrawTexture 
    Canvas->K2_DrawTexture(
        nullptr,                   // RenderTexture
        Position,                  // ScreenPosition
        FVector2D(Width, Height),  // ScreenSize
        FVector2D(0, 0),           // CoordinatePosition
        FVector2D(1, 1),           // CoordinateSize
        Color,                     // RenderColor
        EBlendMode::BLEND_Translucent, // BlendMode
        0.0f,                      // Rotation
        FVector2D(0, 0)            // RotPivot
    );
}

void DrawOutlinedText(UCanvas* Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false)
{
	Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void DrawText(UCanvas* Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, int FontSize, bool isCenter) {
	robotoTinyFont->LegacyFontSize = FontSize;
	Canvas->K2_DrawText(robotoTinyFont, Text, Pos, Color, 1.f, {}, {}, isCenter, false, true, OutlineColor);
	robotoTinyFont->LegacyFontSize = 13;
}
void Drawtext(UCanvas* Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, int FontSize, bool isCenter) {
    tslFont->LegacyFontSize = FontSize;
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, false, false,OutlineColor); // Removed outline parameters
    tslFont->LegacyFontSize = 14;
}

void DrawOutlinedTexxt(UCanvas* Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false)
{
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, false, {});
}

void DrawOutlinedTextFPS(UCanvas* Canvas, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false)
{
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void DrawLine(UCanvas* Canvas, FVector2D posFrom, FVector2D posTo, float Thickness, FLinearColor Color) {
    Canvas->K2_DrawLine({posFrom.X, posFrom.Y}, {posTo.X, posTo.Y}, Thickness, Color);
}

void DrawFilledRect(UCanvas* Canvas, FVector2D initial_pos, float w, float h, FLinearColor Color)
{
    for (float i = 0.f; i < h; i += 1.f)
    Canvas->K2_DrawLine(FVector2D(initial_pos.X, initial_pos.Y + i), FVector2D(initial_pos.X + w, initial_pos.Y + i), 1.f, Color);
}

 


void DrawRectangle(UCanvas* Canvas, FVector2D Pos, float Width, float Height, float Thickness, FLinearColor Color) {
	Canvas->K2_DrawLine(FVector2D(Pos.X, Pos.Y), FVector2D(Pos.X + Width, Pos.Y), Thickness, Color);
	Canvas->K2_DrawLine(FVector2D(Pos.X, Pos.Y), FVector2D(Pos.X, Pos.Y + Height), Thickness, Color);
	Canvas->K2_DrawLine(FVector2D(Pos.X + Width, Pos.Y), FVector2D(Pos.X + Width, Pos.Y + Height), Thickness, Color);
	Canvas->K2_DrawLine(FVector2D(Pos.X, Pos.Y + Height), FVector2D(Pos.X + Width, Pos.Y + Height), Thickness, Color);
}

void DrawCircle(UCanvas* Canvas, float x, float y, float radius, int numsides, FLinearColor OutlineColor){
    float Step = M_PI * 2.0 / numsides;
	int Count = 0;
	FVector2D V[128];
	for (float a = 0; a < M_PI * 2.0; a += Step)
	{
		float X1 = radius * cos(a) + x;
		float Y1 = radius * sin(a) + y;
		float X2 = radius * cos(a + Step) + x;
		float Y2 = radius * sin(a + Step) + y;
		V[Count].X = X1;
		V[Count].Y = Y1;
		V[Count + 1].X = X2;
		V[Count + 1].Y = Y2;
		Canvas->K2_DrawLine(FVector2D(V[Count].X, V[Count].Y), FVector2D(X2, Y2), 1.f, OutlineColor);
	}
}


namespace EagleGUI
{
	namespace Colors
	{
        FLinearColor Text{ 1.f, 1.f, 1, 1.f };
  FLinearColor Text_Shadow{ 1.f, 1.f, 1, 1.f };
  FLinearColor Text_Outline{ 0, 0, 0, 1.f };

  FLinearColor Window_Background{ 1.f, 1.f, 1.f, 1.f };
  FLinearColor Window_Header{ 1.f, 1.f, 1.f, 1.f };
        FLinearColor Window_Head{ 0, 0, 0, 1.f };
        
  FLinearColor Button_Idle{ 0.33f, 0.30f, 0.90f, 1.0f };
  FLinearColor Button_Hovered{ 0.15f, 0.20f, 0.89f, 1.0f };
  FLinearColor Button_Active{ 0.20f, 0.25f, 0.94f, 1.0f };

        FLinearColor Checkbox_GUBAI{ 0.17f, 0.16f, 0.23f, 1.0f };
        FLinearColor InputBox{ 1.f, 0.4f, 0, 1.f };
  FLinearColor Checkbox_Idle{ 0.17f, 0.16f, 0.23f, 1.0f };
  FLinearColor Checkbox_Hovered{ 0.22f, 0.30f, 0.72f, 1.0f };
  FLinearColor Checkbox_Enabled{ 0.20f, 0.25f, 0.94f, 1.0f };

  FLinearColor Combobox_Idle{ 0.17f, 0.16f, 0.23f, 1.0f };
  FLinearColor Combobox_Hovered{ 0.17f, 0.16f, 0.23f, 1.0f };
  FLinearColor Combobox_Elements{ 0.239f, 0.42f, 0.82f, 1.0f };

  FLinearColor Slider_Idle{ 0.17f, 0.16f, 0.23f, 1.0f };
  FLinearColor Slider_Hovered{ 0.17f, 0.16f, 0.23f, 1.0f };
  FLinearColor Slider_Progress{ 0.67f, 0.57f, 0.81f, 1.0f };
  FLinearColor Slider_Button{ 0.2f, 0.6f, 0.9f, 1.0f };

  FLinearColor ColorPicker_Background{ 0.006f, 0.006f, 0.006f, 1.0f };
	}

	namespace PostRenderer
	{
		struct DrawList
		{
			int type = -1; //1 = FilledRect, 2 = TextLeft, 3 = TextCenter, 4 = Draw_Line
			FVector2D pos;
			FVector2D size;
			FLinearColor color;
			char* name;
			bool outline;

			FVector2D from;
			FVector2D to;
			int thickness;
		};
		DrawList drawlist[128];

		void drawFilledRect(FVector2D pos, float w, float h, FLinearColor color)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 1;
					drawlist[i].pos = pos;
					drawlist[i].size = FVector2D{ w, h };
					drawlist[i].color = color;
					return;
				}
			}
		}
		void TextLeft(char* name, FVector2D pos, FLinearColor color, bool outline)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 2;
					drawlist[i].name = name;
					drawlist[i].pos = pos;
					drawlist[i].outline = outline;
					drawlist[i].color = color;
					return;
				}
			}
		}
		void TextCenter(char* name, FVector2D pos, FLinearColor color, bool outline)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 3;
					drawlist[i].name = name;
					drawlist[i].pos = pos;
					drawlist[i].outline = outline;
					drawlist[i].color = color;
					return;
				}
			}
		}
		void Draw_Line(FVector2D from, FVector2D to, int thickness, FLinearColor color)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 4;
					drawlist[i].from = from;
					drawlist[i].to = to;
					drawlist[i].thickness = thickness;
					drawlist[i].color = color;
					return;
				}
			}
		}
	}

	UCanvas* Canvas;
	void* font;

	bool hover_element = false;
	FVector2D menu_pos = FVector2D{ 0, 0 };
	float offset_x = 0.0f;
	float offset_y = 0.0f;

	FVector2D first_element_pos = FVector2D{ 0, 0 };

	FVector2D last_element_pos = FVector2D{ 0, 0 };
	FVector2D last_element_size = FVector2D{ 0, 0 };

	int current_element = -1;
	FVector2D current_element_pos = FVector2D{ 0, 0 };
	FVector2D current_element_size = FVector2D{ 0, 0 };
	int elements_count = 0;

	bool sameLine = false;

	bool pushY = false;
	float pushYvalue = 0.0f;
    
    bool mouseDownAlready[256];

    FVector2D MousePos = {0,0};
    bool MouseDown = false;


    bool IsMouseClicked(int button, int element_id, bool repeat)
    {
        if (MouseDown)
        {
            if (!mouseDownAlready[element_id])
            {
                mouseDownAlready[element_id] = true;
                return true;
            }
            if (repeat)
                return true;
        }
        else
        {
            mouseDownAlready[element_id] = false;
        }
        return false;
	}

	void SetupCanvas(UCanvas* _Canvas, void* _font)
	{
		Canvas = _Canvas;
		font = _font;
	}

	FVector2D CursorPos()
    {
        return MousePos;
	}
	
	bool MouseInZone(FVector2D pos, FVector2D size)
    {
        FVector2D cursor_pos = CursorPos();
        if (cursor_pos.X > pos.X && cursor_pos.Y > pos.Y)
            if (cursor_pos.X < pos.X + size.X && cursor_pos.Y < pos.Y + size.Y)
                return true;

        return false;
	}
	void Draw_Cursor(bool toogle)
	{
		if (toogle)
		{
			FVector2D cursorPos = CursorPos();
		    Canvas->K2_DrawLine(FVector2D{ cursorPos.X, cursorPos.Y }, FVector2D{ cursorPos.X + 35, cursorPos.Y + 10 }, 1, FLinearColor{ 0.30f, 0.30f, 0.80f, 1.0f });


			int x = 35;
			int y = 10;
			while (y != 30) //20 steps
			{
				x -= 1; if (x < 15) x = 15;
				y += 1; if (y > 30) y = 30;

				Canvas->K2_DrawLine(FVector2D{ cursorPos.X, cursorPos.Y }, FVector2D{ cursorPos.X + x, cursorPos.Y + y }, 1, FLinearColor{ 0.30f, 0.30f, 0.80f, 1.0f });
			}

			Canvas->K2_DrawLine(FVector2D{ cursorPos.X, cursorPos.Y }, FVector2D{ cursorPos.X + 15, cursorPos.Y + 30 }, 1, FLinearColor{ 0.30f, 0.30f, 0.80f, 1.0f });
			Canvas->K2_DrawLine(FVector2D{ cursorPos.X + 35, cursorPos.Y + 10 }, FVector2D{ cursorPos.X + 15, cursorPos.Y + 30 }, 1, FLinearColor{ 0.30f, 0.30f, 0.80f, 1.0f });
		}
	}

	void SameLine()
	{
		sameLine = true;
	}
	
	void PushNextElementY(float y, bool from_last_element = true)
	{
		pushY = true;
		if (from_last_element)
			pushYvalue = last_element_pos.Y + last_element_size.Y + y;
		else
			pushYvalue = y;
	}
	void NextColumn(float x)
	{
		offset_x = x;
		PushNextElementY(first_element_pos.Y, false);
	}
	void 下一行(float y)
	{
		offset_y = y;
		PushNextElementY(first_element_pos.X, false);
	}
	void ClearFirstPos()
	{
		first_element_pos = FVector2D{ 0, 0 };
	}

	void TextLeft(const char* name, FVector2D pos, FLinearColor color, bool outline)
	{
		int length = strlen(name) + 1;
		Canvas->K2_DrawText(tslFont, FString(name),pos, color, false, Colors::Text_Shadow, FVector2D{ pos.X + 1, pos.Y + 1 }, false, true, true, Colors::Text_Outline);    
	}
	void TextCenter(const char* name, FVector2D pos, FLinearColor color, bool outline)
	{
		int length = strlen(name) + 1;
		Canvas->K2_DrawText(tslFont, FString(name),pos, color, false, Colors::Text_Shadow, FVector2D{ pos.X + 1, pos.Y + 1 }, true, true, true, Colors::Text_Outline);
	}
	
void K2_DrawLine(FVector2D start, FVector2D end, float Thickness, FLinearColor col) {
		DrawLine(EagleGUI::Canvas,FVector2D{ start.X, start.Y }, FVector2D{ end.X, end.Y }, Thickness, col);
    //你的实现代码
}

	void GetColor(FLinearColor* color, float* r, float* g, float* b, float* a)
	{
		*r = color->R;
		*g = color->G;
		*b = color->B;
		*a = color->A;
	}
	UINT32 GetColorUINT(int r, int g, int b, int a)
	{
		UINT32 result = (BYTE(a) << 24) + (BYTE(r) << 16) + (BYTE(g) << 8) + BYTE(b);
		return result;
	}

	void Draw_Line(FVector2D from, FVector2D to, int thickness, FLinearColor color)
	{
		Canvas->K2_DrawLine(FVector2D{ from.X, from.Y }, FVector2D{ to.X, to.Y }, thickness, color);
	}
	void drawFilledRect(FVector2D initial_pos, float w, float h, FLinearColor color)
	{
		for (float i = 0.0f; i < h; i += 1.0f)
		Canvas->K2_DrawLine(FVector2D{ initial_pos.X, initial_pos.Y + i }, FVector2D{ initial_pos.X + w, initial_pos.Y + i }, 1.0f, color);
	}
	void DrawFilledCircle(FVector2D pos, float r, FLinearColor color)
	{
		float smooth = 0.01f;
        float Pl = 3.1415927f;
		double kj = 3.14159265359;
		int size = (int)(2.0f * kj / smooth) + 1;

		float angle = 0.0f;
		int i = 0;

		for (; angle < 2 * Pl; angle += smooth, i++)
		{
			Draw_Line(FVector2D{ pos.X, pos.Y }, FVector2D{ pos.X + cosf(angle) * r, pos.Y + sinf(angle) * r }, 1.0f, color);
		}
	}
	void DrawCircle(FVector2D pos, int radius, int numSides, FLinearColor Color)
	{
		float Pl = 3.1415927f;

		float Step = Pl * 2.0 / numSides;
		int Count = 0;
		FVector2D V[128];
		for (float a = 0; a < Pl * 2.0; a += Step) {
			float X1 = radius * cos(a) + pos.X;
			float Y1 = radius * sin(a) + pos.Y;
			float X2 = radius * cos(a + Step) + pos.X;
			float Y2 = radius * sin(a + Step) + pos.Y;
			V[Count].X = X1;
			V[Count].Y = Y1;
			V[Count + 1].X = X2;
			V[Count + 1].Y = Y2;
			//Draw_Line(FVector2D{ pos.X, pos.Y }, FVector2D{ X2, Y2 }, 1.0f, Color); // Points from Centre to ends of circle
			Draw_Line(FVector2D{ V[Count].X, V[Count].Y }, FVector2D{ X2, Y2 }, 1.0f, Color);// Circle Around
		}
	}
	FVector2D dragPos;
	FVector2D movePos;
	FVector2D origPos;
    
	bool Window(char* name, FVector2D* pos, FVector2D size, bool& isOpen, float& tempValue)
	{
		elements_count = 0;
		
		bool isHovered = MouseInZone(FVector2D{ pos->X, pos->Y }, isOpen ? size : FVector2D(size.X, 35.0f));

		//Drop last element
		if (current_element != -1 && !MouseDown)
		{
			current_element = -1;
		}

		//Drag
		if (hover_element && MouseDown)
		{

		}
		else if ((isHovered || dragPos.X != 0) && !hover_element)
		{
			if (IsMouseClicked(0, elements_count, true))
			{
				FVector2D cursorPos = CursorPos();

				cursorPos.X -= size.X;
				cursorPos.Y -= size.Y;

				if (dragPos.X == 0)
				{
					dragPos.X = (cursorPos.X - pos->X);
					dragPos.Y = (cursorPos.Y - pos->Y);
					origPos = {cursorPos.X - dragPos.X, cursorPos.Y - dragPos.Y};
					// 判断点击点是否在标题栏内
    		        bool isClickedTitle = MouseInZone(FVector2D{ pos->X, pos->Y }, {size.X, 25.0f});
    		        if(isClickedTitle){
    		            tempValue = 1.0f;
    		        }else{
    		            tempValue = 0.0f;
    		        }
				}								
				pos->X = cursorPos.X - dragPos.X;
				pos->Y = cursorPos.Y - dragPos.Y;											
			}
			else
			{			
				dragPos = FVector2D{ 0, 0 };
				if(tempValue && abs(origPos.X - pos->X) <= 10 && abs(origPos.Y - pos->Y) <= 10){
				    tempValue = 0;
				    isOpen = !isOpen;
				}
			}
		}
		else
		{
			hover_element = false;
		}

		offset_x = 0.0f; offset_y = 0.0f;
		menu_pos = FVector2D{ pos->X, pos->Y };
		first_element_pos = FVector2D{ 0, 0 };
		current_element_pos = FVector2D{ 0, 0 };
		current_element_size = FVector2D{ 0, 0 };
	    
	    if (isOpen)
	        // Bg
	        drawFilledRect(FVector2D{ pos->X, pos->Y }, size.X, size.Y, Colors::Window_Background);

	    
	    //Header
		drawFilledRect(FVector2D{ pos->X, pos->Y }, size.X, 35.0f, Colors::Window_Header);

		offset_y += 35.0f;

		//Title
		FVector2D titlePos = FVector2D{ pos->X + size.X / 2, pos->Y + 35.0f / 2 };
		TextCenter(name, titlePos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f },true);
		
			
	        
		return isOpen;
	}
	void 文本(const char* text, bool center = false, bool outline = false)
	{
		elements_count++;

		float size = 12.5;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}

		if (!sameLine)
			offset_y += size + padding.Y;

		//Text      pos.x - 向左 pos.y + 向下
		FVector2D textPos = FVector2D{ pos.X - 5.0f, pos.Y + size / 2 + 5.0f };

		if (center)
			TextCenter(text, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);
		else
			TextLeft(text, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);

		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}
	void Text(const char* text, bool center = false, bool outline = false)
	{
		elements_count++;

		float size = 12.5;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}

		if (!sameLine)
			offset_y += size + padding.Y;

		//Text
		FVector2D textPos = FVector2D{ pos.X + 5.0f, pos.Y + size / 2 };
		if (center)
			TextCenter(text, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);
		else
			TextLeft(text, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);

		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
		first_element_pos = pos;
	}
	bool ButtonTab(const char* name, FVector2D size, bool active)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
        
        float radius = 15.0f;
        FLinearColor circleColor = COLOR_BLACK;
       // DrawRectangle(Canvas, FVector2D(pos.X + 14.1 - radius, pos.Y + 14.1 - radius), radius * 6.8, radius * 2.7, 1.0f, circleColor);

		//Bg
		if (active)
		{		  
            
		    drawFilledRect(FVector2D{ pos.X + 5, pos.Y+5}, size.X, size.Y, Colors::Button_Hovered);
		}
		else if (isHovered)
		{
		       
			drawFilledRect(FVector2D{ pos.X + 5 , pos.Y+5}, size.X, size.Y, Colors::Button_Active);
			hover_element = true;
		}
		else
		{		            
			drawFilledRect(FVector2D{ pos.X + 5, pos.Y+5}, size.X, size.Y, Colors::Button_Idle);
		}		     
		       
		if (!sameLine)
			offset_y += size.Y + padding.Y;

		//Text
		FVector2D textPos = FVector2D{ pos.X + 5+ size.X / 2, pos.Y + 5 + size.Y / 2 };
		TextCenter(name, textPos, FLinearColor{COLOR_WHITE}, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && IsMouseClicked(0, elements_count, false))
			return true;

		return false;
	}
	bool Button(const char* name, FVector2D size)
	{
		elements_count++;
		
		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
		
		//Bg
		if (isHovered)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Idle);
		}
		
		if (!sameLine)
			offset_y += size.Y + padding.Y;
		
		//Text
		FVector2D textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };	
    	TextCenter(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
		
		
		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
		
		if (isHovered && IsMouseClicked(0, elements_count, false))
			return true;
		
		return false;
	}
	bool 方框(const char* name, FVector2D size)
	{
		elements_count++;
		
		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
		
		//Bg
		if (isHovered)
		{
		    drawFilledRect(FVector2D{pos.X + 122.2, pos.Y}, size.X - 127.9, size.Y,Colors::Button_Idle);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{pos.X + 122.2, pos.Y}, size.X - 127.9, size.Y,Colors::Button_Idle);
		}
		
		if (!sameLine)
			offset_y += size.Y + padding.Y;
		
		//Text
		FVector2D textPos = FVector2D{ pos.X + size.X / 2 + 49.7, pos.Y + size.Y / 2};	
    	TextCenter(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
		
		
		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
		
		if (isHovered && IsMouseClicked(0, elements_count, false))
			return true;
		
		return false;
	}
	bool 输入框(const char* name, FVector2D size)
	{
		elements_count++;
		
		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
		
		//Bg
		if (isHovered)
		{			
		    drawFilledRect(FVector2D{pos.X + 139.6, pos.Y + 15}, size.X - 114.9, size.Y, Colors::InputBox);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{pos.X + 139.6, pos.Y + 15}, size.X - 114.9, size.Y, Colors::InputBox);
		}
		
		if (!sameLine)
			offset_y += size.Y + padding.Y;
		
		//Text
		FVector2D textPos = FVector2D{pos.X + size.X / 2 + 78.1, pos.Y + size.Y / 2 + 16};	
    	TextCenter(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
		
		
		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
		    first_element_pos = pos;
		
		if (isHovered && IsMouseClicked(0, elements_count, false))
			return true;
		
		return false;
	}
	
	bool Checkbox(char* name, bool* value)
	{
		elements_count++;
		
		float size = 30;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ size, size });
		
		//Bg
		if (isHovered)
		{
			hover_element = true;
		}
		
    	float radius = 15.0f;
	    FLinearColor circleColor = Colors::Window_Head;
        DrawRectangle(Canvas, FVector2D(pos.X + 10 - radius, pos.Y + 15 - radius), radius * 2, radius * 2, 0.0f, circleColor);
	
	
		if (!sameLine)
			offset_y += size + padding.Y;
	
		if (*value)
		{
		
        Draw_Line(FVector2D{pos.X + 3 - 1.4, pos.Y + 7 + 7.3}, FVector2D{pos.X + 13 - 4.3, pos.Y + 17 + 3.1}, 2.0f, Colors::Checkbox_GUBAI);
        Draw_Line(FVector2D{pos.X + 13 + 5.8, pos.Y + 7 - 3.3}, FVector2D{pos.X + 3 + 6.9, pos.Y + 17 + 4.5}, 2.0f,Colors::Checkbox_GUBAI);        
        
		}
		
		
		
		//Text
		FVector2D textPos = FVector2D{ pos.X + size, pos.Y + size / 2 };
		//if (!TextOverlapedFromActiveElement(textPos))
		TextLeft(name, textPos, FLinearColor{1.0f, 1.0f, 1.0f, 1.0f}, false);
		
		
		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
		
		if (isHovered && IsMouseClicked(0, elements_count, false)){
			*value = !*value;
			return true;
	    }
	    return false;
	}	
	bool CheckCircle(char* name, bool* value)
	{
		elements_count++;
		
		float size = 30;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ size, size });
		
		//Bg
		if (isHovered)
		{
			hover_element = true;
		}
		
		DrawCircle(FVector2D{ pos.X+15.0f, pos.Y+15.0f }, 15.0f, 15.0f, Colors::Checkbox_Idle);
		// drawFilledRect(FVector2D{ pos.X, pos.Y }, size, size, Colors::Checkbox_Idle);
	
		if (!sameLine)
			offset_y += size + padding.Y;
	
		if (*value)
		{
		    DrawFilledCircle(FVector2D{ pos.X+15.0f, pos.Y+15.0f}, 12.0f, Colors::Checkbox_Enabled);
		}
								
		//Text
		FVector2D textPos = FVector2D{ pos.X + size + 5.0f, pos.Y + size / 2 };
		//if (!TextOverlapedFromActiveElement(textPos))
			TextLeft(name, textPos, FLinearColor{1.0f, 1.0f, 1.0f, 1.0f}, false);
		
		
		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
		
		if (isHovered && IsMouseClicked(0, elements_count, false)){
			*value = !*value;
			return true;
	    }
	    return false;
	}
	bool SliderInt(const char* name, int* value, int min, int max, const char* format="%i")
	{
		elements_count++;

		FVector2D size = FVector2D{ 240, 50 };
		FVector2D slider_size = FVector2D{ 200, 10 };
		FVector2D padding = FVector2D{ 10, 15 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size);

		if (!sameLine)
			offset_y += size.Y + padding.Y;
        bool change = false;
		//Bg
		if (isHovered || current_element == elements_count)
		{
			//Drag
			if (IsMouseClicked(0, elements_count, true))
			{
				current_element = elements_count;

				FVector2D cursorPos = CursorPos();
				*value = ((cursorPos.X - pos.X) * ((max - min) / slider_size.X)) + min;
				if (*value < min) *value = min;
				if (*value > max) *value = max;
				change = true;
			}

            drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Hovered);
			DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
			DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Hovered);

			hover_element = true;
		}
		else
		{
        	drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Idle);
			DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
			DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Idle);
		}


		//Value
	    float oneP = slider_size.X / (max - min);
		drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, oneP * (*value - min), slider_size.Y, Colors::Slider_Progress);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 8.0f, Colors::Slider_Button);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 4.0f, Colors::Slider_Progress);


		char buffer[32];
		sprintf(buffer, format, *value);
		FVector2D valuePos = FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 25 + padding.Y };
		TextCenter(buffer, valuePos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

		//Text
		FVector2D textPos = FVector2D{ pos.X + 5, pos.Y + 10 };
		TextLeft(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
		return change;
}        
bool SliderFloat(const char* name, float* value, float min, float max, const char* format = "%.0f")
{
    elements_count++; // 增加元素计数

    FVector2D size = FVector2D{ 210, 40 };
    FVector2D slider_size = FVector2D{ 400, 7 };
	FVector2D adjust_zone = FVector2D{ 0, 20 };
	FVector2D padding = FVector2D{ 10, 15 };
	FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };

    // 如果在同一行，则将位置更新为上一个元素的右侧
    if (sameLine)
    {
        pos.X = last_element_pos.X + last_element_size.X + padding.X;
        pos.Y = last_element_pos.Y;
    }

    // 如果有垂直偏移，则调整位置
    if (pushY)
    {
        pos.Y = pushYvalue;
        pushY = false;
        pushYvalue = 0.0f;
        offset_y = pos.Y - menu_pos.Y;
    }

    // 检查鼠标是否悬停在滑动条上
    bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y - adjust_zone.Y }, FVector2D{ slider_size.X, slider_size.Y + adjust_zone.Y * 1.5f });

    // 如果不在同一行，则更新垂直偏移
    if (!sameLine)
        offset_y += size.Y + padding.Y;

    bool change = false; // 是否值发生变化
    
    // 绘制背景和滑块
    if (isHovered || current_element == elements_count)
    {
        // 如果鼠标按下，则进行拖动
        if (IsMouseClicked(0, elements_count, true))
        {
            current_element = elements_count;

            FVector2D cursorPos = CursorPos();
            // 根据鼠标位置更新值
            *value = ((cursorPos.X - pos.X) * ((max - min) / slider_size.X)) + min;
            // 确保值在最小和最大值之间
            if (*value < min) *value = min;
            if (*value > max) *value = max;
            change = true;
        }


		drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Hovered);
		DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
		DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Hovered);

		hover_element = true;
    }
    else
    {
        
        drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Idle);
		DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
		DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Idle);
        
    }

    // 绘制名称文本
    FVector2D textPos = FVector2D{ pos.X, pos.Y + 5};
    TextLeft(name, textPos, Colors::Text, false);

    // 绘制值及滑块    
    float oneP = slider_size.X / (max - min);
	drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, oneP * (*value - min), slider_size.Y, Colors::Slider_Progress);
	DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 8.0f, Colors::Slider_Button);
	DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 4.0f, Colors::Slider_Progress);

    // 绘制值文本
    char buffer[64];
    sprintf(buffer, format, *value); // 格式化值
    FVector2D valuePos = FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 20 + padding.Y + 15 };
    TextCenter(buffer, valuePos, Colors::Text, false); // 居中绘制文本

    sameLine = false; // 重置同一行标志
    last_element_pos = pos; // 更新上一个元素的位置
    last_element_size = size; // 更新上一个元素的大小
    if (first_element_pos.X == 0.0f) // 如果是第一个元素，则更新第一个元素的位置
        first_element_pos = pos;

    return change; // 返回是否值发生变化
}
    
bool checkbox_enabled[256]; // 用于存储复选框的启用状态的数组

// 渲染下拉框 UI 元素的函数
bool Combobox(char* name, FVector2D size, int* value, const char* arg, ...)
{
    elements_count++; // 增加 UI 元素的计数

    FVector2D padding = FVector2D{ 5, 10 };
    FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
    if (sameLine) // 如果元素应该在与上一个元素相同的行上渲染
    {
        pos.X = last_element_pos.X + last_element_size.X + padding.X;
        pos.Y = last_element_pos.Y;
    }
    if (pushY) // 如果需要推动 Y 轴位置
    {
        pos.Y = pushYvalue;
        pushY = false;
        pushYvalue = 0.0f;
        offset_y = pos.Y - menu_pos.Y;
    }
    bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

    // 背景
    if (isHovered || checkbox_enabled[elements_count])
    {
        drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Combobox_Hovered);
        hover_element = true;
    }
    else
    {
        drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Combobox_Idle);
    }

    if (!sameLine)
        offset_y += size.Y + padding.Y;

    // 文本
    FVector2D textPos = FVector2D{ pos.X + size.X + 5.0f, pos.Y + size.Y / 2 };
    TextLeft(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

    // 元素
    bool isHovered2 = false;
    FVector2D element_pos = pos;
    int num = 0;

    if (checkbox_enabled[elements_count])
    {
        current_element_size.X = element_pos.X - 5.0f;
        current_element_size.Y = element_pos.Y - 5.0f;
    }
    va_list arguments;
    for (va_start(arguments, arg); arg != NULL; arg = va_arg(arguments, const char*))
    {
        // 选中的元素
        if (num == *value)
        {
            FVector2D _textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
            TextCenter((char*)arg, _textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
        }

        if (checkbox_enabled[elements_count])
        {
            element_pos.Y += 25.0f;

            isHovered2 = MouseInZone(FVector2D{ element_pos.X, element_pos.Y }, FVector2D{ size.X, 25.0f });
            if (isHovered2)
            {
                hover_element = true;
                PostRenderer::drawFilledRect(FVector2D{ element_pos.X, element_pos.Y }, size.X, 25.0f, Colors::Combobox_Hovered);

                // 单击事件
                if (IsMouseClicked(0, elements_count, false))
                {
                    *value = num;
                    checkbox_enabled[elements_count] = false;
                }
            }
            else
            {
                PostRenderer::drawFilledRect(FVector2D{ element_pos.X, element_pos.Y }, size.X, 25.0f, Colors::Combobox_Idle);
            }

            PostRenderer::TextLeft((char*)arg, FVector2D{ element_pos.X + 5.0f, element_pos.Y + 15.0f }, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
        }
        num++;
    }
    va_end(arguments);
    if (checkbox_enabled[elements_count])
    {
        current_element_size.X = element_pos.X + 5.0f;
        current_element_size.Y = element_pos.Y + 5.0f;
    }

    sameLine = false;
    last_element_pos = pos;
    last_element_size = size;
    if (first_element_pos.X == 0.0f)
        first_element_pos = pos;

    if (isHovered && IsMouseClicked(0, elements_count, false)){
        *value = !*value;
        return true;
    }
    return false;
}

	int active_picker = -1;
	FLinearColor saved_color;
	bool ColorPixel(FVector2D pos, FVector2D size, FLinearColor* original, FLinearColor color)
	{
		PostRenderer::drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, color);

		//Выбранный цвет
		if (original->R == color.R && original->G == color.G && original->B == color.B)
		{
			PostRenderer::Draw_Line(FVector2D{ pos.X, pos.Y }, FVector2D{ pos.X + size.X - 1, pos.Y }, 1.0f, FLinearColor{ 0.0f, 0.0f, 0.0f, 1.0f });
			PostRenderer::Draw_Line(FVector2D{ pos.X, pos.Y + size.Y - 1 }, FVector2D{ pos.X + size.X - 1, pos.Y + size.Y - 1 }, 1.0f, FLinearColor{ 0.0f, 0.0f, 0.0f, 1.0f });
			PostRenderer::Draw_Line(FVector2D{ pos.X, pos.Y }, FVector2D{ pos.X, pos.Y + size.Y - 1 }, 1.0f, FLinearColor{ 0.0f, 0.0f, 0.0f, 1.0f });
			PostRenderer::Draw_Line(FVector2D{ pos.X + size.X - 1, pos.Y }, FVector2D{ pos.X + size.X - 1, pos.Y + size.Y - 1 }, 1.0f, FLinearColor{ 0.0f, 0.0f, 0.0f, 1.0f });
		}

		//Смена цвета
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
		if (isHovered)
		{
			if (IsMouseClicked(0, elements_count, false))
				*original = color;
		}

		return true;
	}
	void ColorPicker(const char* name, FLinearColor* color)
	{
		elements_count++;

		float size = 25;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ size, size });

		if (!sameLine)
			offset_y += size + padding.Y;

		if (active_picker == elements_count)
		{
			hover_element = true;

			float sizePickerX = 250;
			float sizePickerY = 250;
			bool isHoveredPicker = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ sizePickerX, sizePickerY - 60 });

			//Background
			PostRenderer::drawFilledRect(FVector2D{ pos.X, pos.Y }, sizePickerX, sizePickerY - 65, Colors::ColorPicker_Background);

			FVector2D pixelSize = FVector2D{ sizePickerX/12, sizePickerY/12 };

			//0
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 174/255.f, 235/255.f, 253/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 136/255.f, 225/255.f, 251/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 108/255.f, 213/255.f, 250/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 89/255.f, 175/255.f, 213/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 76/255.f, 151/255.f, 177/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 60/255.f, 118/255.f, 140/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 43/255.f, 85/255.f, 100/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 32/255.f, 62/255.f, 74/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 255/255.f, 255/255.f, 255/255.f, 1.0f });
			}
			//1
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 175/255.f, 205/255.f, 252/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 132/255.f, 179/255.f, 252/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 90/255.f, 152/255.f, 250/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 55/255.f, 120/255.f, 250/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 49/255.f, 105/255.f, 209/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 38/255.f, 83/255.f, 165/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 28/255.f, 61/255.f, 120/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 20/255.f, 43/255.f, 86/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 247/255.f, 247/255.f, 247/255.f, 1.0f });
			}
			//2
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 153/255.f, 139/255.f, 250/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 101/255.f, 79/255.f, 249/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 64/255.f, 50/255.f, 230/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 54/255.f, 38/255.f, 175/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 39/255.f, 31/255.f, 144/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 32/255.f, 25/255.f, 116/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 21/255.f, 18/255.f, 82/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 16/255.f, 13/255.f, 61/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 228/255.f, 228/255.f, 228/255.f, 1.0f });
			}
			//3
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 194/255.f, 144/255.f, 251/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 165/255.f, 87/255.f, 249/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 142/255.f, 57/255.f, 239/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 116/255.f, 45/255.f, 184/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 92/255.f, 37/255.f, 154/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 73/255.f, 29/255.f, 121/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 53/255.f, 21/255.f, 88/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 37/255.f, 15/255.f, 63/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 203/255.f, 203/255.f, 203/255.f, 1.0f });
			}
			//4
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 224/255.f, 162/255.f, 197/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 210/255.f, 112/255.f, 166/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 199/255.f, 62/255.f, 135/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 159/255.f, 49/255.f, 105/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 132/255.f, 41/255.f, 89/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 104/255.f, 32/255.f, 71/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 75/255.f, 24/255.f, 51/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 54/255.f, 14/255.f, 36/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 175/255.f, 175/255.f, 175/255.f, 1.0f });
			}
			//5
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 235/255.f, 175/255.f, 176/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 227/255.f, 133/255.f, 135/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 219/255.f, 87/255.f, 88/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 215/255.f, 50/255.f, 36/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 187/255.f, 25/255.f, 7/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 149/255.f, 20/255.f, 6/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 107/255.f, 14/255.f, 4/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 77/255.f, 9/255.f, 3/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 144/255.f, 144/255.f, 144/255.f, 1.0f });
			}
			//6
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 241/255.f, 187/255.f, 171/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 234/255.f, 151/255.f, 126/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 229/255.f, 115/255.f, 76/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 227/255.f, 82/255.f, 24/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 190/255.f, 61/255.f, 15/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 150/255.f, 48/255.f, 12/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 107/255.f, 34/255.f, 8/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 79/255.f, 25/255.f, 6/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 113/255.f, 113/255.f, 113/255.f, 1.0f });
			}
			//7
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 245/255.f, 207/255.f, 169/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 240/255.f, 183/255.f, 122/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 236/255.f, 159/255.f, 74/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 234/255.f, 146/255.f, 37/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 193/255.f, 111/255.f, 28/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 152/255.f, 89/255.f, 22/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 110/255.f, 64/255.f, 16/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 80/255.f, 47/255.f, 12/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 82/255.f, 82/255.f, 82/255.f, 1.0f });
			}
			//8
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 247/255.f, 218/255.f, 170/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 244/255.f, 200/255.f, 124/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 241/255.f, 182/255.f, 77/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 239/255.f, 174/255.f, 44/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 196/255.f, 137/255.f, 34/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 154/255.f, 108/255.f, 27/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 111/255.f, 77/255.f, 19/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 80/255.f, 56/255.f, 14/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 54/255.f, 54/255.f, 54/255.f, 1.0f });
			}
			//9
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 254/255.f, 243/255.f, 187/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 253/255.f, 237/255.f, 153/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 253/255.f, 231/255.f, 117/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 254/255.f, 232/255.f, 85/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 242/255.f, 212/255.f, 53/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 192/255.f, 169/255.f, 42/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 138/255.f, 120/255.f, 30/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 101/255.f, 87/255.f, 22/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 29/255.f, 29/255.f, 29/255.f, 1.0f });
			}
			//10
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 247/255.f, 243/255.f, 185/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 243/255.f, 239/255.f, 148/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 239/255.f, 232/255.f, 111/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 235/255.f, 229/255.f, 76/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 208/255.f, 200/255.f, 55/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 164/255.f, 157/255.f, 43/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 118/255.f, 114/255.f, 31/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 86/255.f, 82/255.f, 21/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 9/255.f, 9/255.f, 9/255.f, 1.0f });
			}
			//11
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 0 }, pixelSize, color, FLinearColor{ 218/255.f, 232/255.f, 182/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 1 }, pixelSize, color, FLinearColor{ 198/255.f, 221/255.f, 143/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 2 }, pixelSize, color, FLinearColor{ 181/255.f, 210/255.f, 103/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 3 }, pixelSize, color, FLinearColor{ 154/255.f, 186/255.f, 76/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 4 }, pixelSize, color, FLinearColor{ 130/255.f, 155/255.f, 64/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 5 }, pixelSize, color, FLinearColor{ 102/255.f, 121/255.f, 50/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 6 }, pixelSize, color, FLinearColor{ 74/255.f, 88/255.f, 36/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 7 }, pixelSize, color, FLinearColor{ 54/255.f, 64/255.f, 26/255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 8 }, pixelSize, color, FLinearColor{ 0/255.f, 0/255.f, 0/255.f, 1.0f });
			}
						
			if (isHoveredPicker)
			{
				if (IsMouseClicked(0, elements_count, false))
				{

				}
			}
			else
			{
				if (IsMouseClicked(0, elements_count, false))
				{
					active_picker = -1;
					//hover_element = false;
				}
			}
		}
		else
		{
			//Bg
			if (isHovered)
			{
				drawFilledRect(FVector2D{ pos.X, pos.Y }, size, size, Colors::Checkbox_Hovered);
				hover_element = true;
			}
			else
			{
				drawFilledRect(FVector2D{ pos.X, pos.Y }, size, size, Colors::Checkbox_Idle);
			}

			//Color
			drawFilledRect(FVector2D{ pos.X + 4, pos.Y + 4 }, size - 8, size - 8, *color);

			//Text
			FVector2D textPos = FVector2D{ pos.X + size + 5.0f, pos.Y + size / 2 };
			TextLeft(name, textPos, FLinearColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

			if (isHovered && IsMouseClicked(0, elements_count, false))
			{
				saved_color = *color;
				active_picker = elements_count;
			}
		}


		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}
	
	void onEvent(AInputEvent* input_event,FVector2D screen_scale) {
     auto event_type = AInputEvent_getType(input_event);
     if(event_type != AINPUT_EVENT_TYPE_MOTION)
       return; // 仅处理触摸事件
     int32_t event_action = AMotionEvent_getAction(input_event);
     int32_t event_pointer_index = (event_action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
     if(event_pointer_index > 0)
       return; // 单指
       event_action &= AMOTION_EVENT_ACTION_MASK;
       switch (event_action) {
          case AMOTION_EVENT_ACTION_DOWN:
          case AMOTION_EVENT_ACTION_UP:
          if ((AMotionEvent_getToolType(input_event, event_pointer_index) == AMOTION_EVENT_TOOL_TYPE_FINGER) || (AMotionEvent_getToolType(input_event, event_pointer_index) == AMOTION_EVENT_TOOL_TYPE_UNKNOWN)) {
              MouseDown = (event_action == AMOTION_EVENT_ACTION_DOWN);
              FVector2D pos(AMotionEvent_getRawX(input_event, event_pointer_index), AMotionEvent_getRawY(input_event, event_pointer_index));
              MousePos = FVector2D(screen_scale.X > 0 ? pos.X / screen_scale.X : pos.X, screen_scale.Y > 0 ? pos.Y / screen_scale.Y : pos.Y);
          }
            break;
          case AMOTION_EVENT_ACTION_BUTTON_PRESS:
          case AMOTION_EVENT_ACTION_BUTTON_RELEASE: {
                int32_t button_state = AMotionEvent_getButtonState(input_event);
                MouseDown = ((button_state & AMOTION_EVENT_BUTTON_PRIMARY) != 0);

          }
            break;
          case AMOTION_EVENT_ACTION_HOVER_MOVE: // Hovering: Tool moves while NOT pressed (such as a physical mouse)
          case AMOTION_EVENT_ACTION_MOVE: {       // Touch pointer moves while DOWN
                FVector2D pos(AMotionEvent_getRawX(input_event, event_pointer_index), AMotionEvent_getRawY(input_event, event_pointer_index));
                MousePos = FVector2D(screen_scale.X > 0 ? pos.X / screen_scale.X : pos.X, screen_scale.Y > 0 ? pos.Y / screen_scale.Y : pos.Y);
                break;
          }
 
       default:
         break;
   }
}


	void Render()
	{
		for (int i = 0; i < 128; i++)
		{
			if (PostRenderer::drawlist[i].type != -1)
			{
				//Filled Rect
				if (PostRenderer::drawlist[i].type == 1)
				{
					EagleGUI::drawFilledRect(PostRenderer::drawlist[i].pos, PostRenderer::drawlist[i].size.X, PostRenderer::drawlist[i].size.Y, PostRenderer::drawlist[i].color);
				}
				//TextLeft
				else if (PostRenderer::drawlist[i].type == 2)
				{
					EagleGUI::TextLeft(PostRenderer::drawlist[i].name, PostRenderer::drawlist[i].pos, PostRenderer::drawlist[i].color, PostRenderer::drawlist[i].outline);
				}
				//TextCenter
				else if (PostRenderer::drawlist[i].type == 3)
				{
					EagleGUI::TextCenter(PostRenderer::drawlist[i].name, PostRenderer::drawlist[i].pos, PostRenderer::drawlist[i].color, PostRenderer::drawlist[i].outline);
				}
				//Draw_Line
				else if (PostRenderer::drawlist[i].type == 4)
				{
					Draw_Line(PostRenderer::drawlist[i].from, PostRenderer::drawlist[i].to, PostRenderer::drawlist[i].thickness, PostRenderer::drawlist[i].color);
				}

				PostRenderer::drawlist[i].type = -1;
			}
		}
	}
}
