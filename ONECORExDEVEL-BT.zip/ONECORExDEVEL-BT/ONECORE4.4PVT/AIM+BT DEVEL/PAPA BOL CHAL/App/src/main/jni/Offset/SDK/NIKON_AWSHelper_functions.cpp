// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.4.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed May 20 07:23:38 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Functions
//---------------------By Tg @Manish8x---------------------------

// Function AWSHelper.AWSHelperBlueprintLibrary.UploadFile
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class UAWSHelper*              CosHelper                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FromFilePath                   (Parm, ZeroConstructor)
// struct FString                 ToURL                          (Parm, ZeroConstructor)
// struct FString                 NoneMatchHeader                (Parm, ZeroConstructor)
// struct FScriptDelegate         OnComplete                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         OnProgress                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UAWSHelperBlueprintLibrary::UploadFile(class UAWSHelper* CosHelper, const struct FString& FromFilePath, const struct FString& ToURL, const struct FString& NoneMatchHeader, const struct FScriptDelegate& OnComplete, const struct FScriptDelegate& OnProgress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.UploadFile");

	UAWSHelperBlueprintLibrary_UploadFile_Params params;
	params.CosHelper = CosHelper;
	params.FromFilePath = FromFilePath;
	params.ToURL = ToURL;
	params.NoneMatchHeader = NoneMatchHeader;
	params.OnComplete = OnComplete;
	params.OnProgress = OnProgress;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function AWSHelper.AWSHelperBlueprintLibrary.UploadBinary
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class UAWSHelper*              CosHelper                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          FromBinaries                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FString                 ToURL                          (Parm, ZeroConstructor)
// struct FString                 NoneMatchHeader                (Parm, ZeroConstructor)
// struct FScriptDelegate         OnComplete                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         OnProgress                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UAWSHelperBlueprintLibrary::UploadBinary(class UAWSHelper* CosHelper, TArray<unsigned char> FromBinaries, const struct FString& ToURL, const struct FString& NoneMatchHeader, const struct FScriptDelegate& OnComplete, const struct FScriptDelegate& OnProgress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.UploadBinary");

	UAWSHelperBlueprintLibrary_UploadBinary_Params params;
	params.CosHelper = CosHelper;
	params.FromBinaries = FromBinaries;
	params.ToURL = ToURL;
	params.NoneMatchHeader = NoneMatchHeader;
	params.OnComplete = OnComplete;
	params.OnProgress = OnProgress;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function AWSHelper.AWSHelperBlueprintLibrary.DownloadFile
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class UAWSHelper*              CosHelper                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FromURL                        (Parm, ZeroConstructor)
// struct FString                 ToFilePath                     (Parm, ZeroConstructor)
// struct FScriptDelegate         OnComplete                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         OnProgress                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UAWSHelperBlueprintLibrary::DownloadFile(class UAWSHelper* CosHelper, const struct FString& FromURL, const struct FString& ToFilePath, const struct FScriptDelegate& OnComplete, const struct FScriptDelegate& OnProgress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.DownloadFile");

	UAWSHelperBlueprintLibrary_DownloadFile_Params params;
	params.CosHelper = CosHelper;
	params.FromURL = FromURL;
	params.ToFilePath = ToFilePath;
	params.OnComplete = OnComplete;
	params.OnProgress = OnProgress;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function AWSHelper.AWSHelperBlueprintLibrary.DownloadBinary
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class UAWSHelper*              CosHelper                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 FromURL                        (Parm, ZeroConstructor)
// struct FScriptDelegate         OnComplete                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         OnProgress                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UAWSHelperBlueprintLibrary::DownloadBinary(class UAWSHelper* CosHelper, const struct FString& FromURL, const struct FScriptDelegate& OnComplete, const struct FScriptDelegate& OnProgress)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.DownloadBinary");

	UAWSHelperBlueprintLibrary_DownloadBinary_Params params;
	params.CosHelper = CosHelper;
	params.FromURL = FromURL;
	params.OnComplete = OnComplete;
	params.OnProgress = OnProgress;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function AWSHelper.AWSHelperBlueprintLibrary.DestroyAWSHelper
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UAWSHelper*              AWSHelper                      (Parm, ZeroConstructor, IsPlainOldData)

void UAWSHelperBlueprintLibrary::DestroyAWSHelper(class UAWSHelper* AWSHelper)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.DestroyAWSHelper");

	UAWSHelperBlueprintLibrary_DestroyAWSHelper_Params params;
	params.AWSHelper = AWSHelper;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function AWSHelper.AWSHelperBlueprintLibrary.ConstructAWSHelper
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UAWSHelper*              ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UAWSHelper* UAWSHelperBlueprintLibrary::ConstructAWSHelper()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSHelperBlueprintLibrary.ConstructAWSHelper");

	UAWSHelperBlueprintLibrary_ConstructAWSHelper_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.IsOK
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UAWSResponse::IsOK()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.IsOK");

	UAWSResponse_IsOK_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetResponseCode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UAWSResponse::GetResponseCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetResponseCode");

	UAWSResponse_GetResponseCode_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetRequestURL
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UAWSResponse::GetRequestURL()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetRequestURL");

	UAWSResponse_GetRequestURL_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetErrorMessage
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UAWSResponse::GetErrorMessage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetErrorMessage");

	UAWSResponse_GetErrorMessage_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetErrorCode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UAWSResponse::GetErrorCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetErrorCode");

	UAWSResponse_GetErrorCode_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetContentAsString
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UAWSResponse::GetContentAsString()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetContentAsString");

	UAWSResponse_GetContentAsString_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function AWSHelper.AWSResponse.GetContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<unsigned char>          ReturnValue                    (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<unsigned char> UAWSResponse::GetContent()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function AWSHelper.AWSResponse.GetContent");

	UAWSResponse_GetContent_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

